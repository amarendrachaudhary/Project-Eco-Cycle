// ==========================================
// Scanner Page JavaScript — EcoCycle AI
// Modified: No price estimation, classify only as recyclable/non-recyclable
// ==========================================

let stream = null;
let isScanning = false;

document.addEventListener('DOMContentLoaded', function() {
    const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const startCameraBtn = document.getElementById('startCamera');
    const captureBtn = document.getElementById('captureBtn');
    const uploadBtn = document.getElementById('uploadBtn');
    const fileInput = document.getElementById('fileInput');
    const cameraPlaceholder = document.getElementById('cameraPlaceholder');
    const scanOverlay = document.getElementById('scanOverlay');
    const detectionBoxes = document.getElementById('detectionBoxes');
    const scanStatus = document.getElementById('scanStatus');
    const clearResultsBtn = document.getElementById('clearResults');

    // Material database — classification only, no prices
    const materials = {
        plastic:   { name: 'Plastic Bottle',   recyclable: true,  bin: 'blue',  weight: 0.05, co2: 0.15 },
        glass:     { name: 'Glass Jar',         recyclable: true,  bin: 'blue',  weight: 0.20, co2: 0.20 },
        paper:     { name: 'Paper/Cardboard',   recyclable: true,  bin: 'blue',  weight: 0.10, co2: 0.10 },
        metal:     { name: 'Metal Can',         recyclable: true,  bin: 'blue',  weight: 0.08, co2: 0.25 },
        copper:    { name: 'Copper Wire',       recyclable: true,  bin: 'blue',  weight: 0.15, co2: 0.30 },
        battery:   { name: 'Battery',           recyclable: false, bin: 'red',   weight: 0.05, co2: 0.00 },
        styrofoam: { name: 'Styrofoam',         recyclable: false, bin: 'red',   weight: 0.02, co2: 0.00 },
        ewaste:    { name: 'Electronic Waste',  recyclable: true,  bin: 'purple',weight: 0.30, co2: 0.50 },
        food:      { name: 'Food Waste',        recyclable: false, bin: 'green', weight: 0.20, co2: 0.00 }
    };

    // Start Camera
    startCameraBtn.addEventListener('click', async function() {
        try {
            stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
            video.srcObject = stream;
            video.style.display = 'block';
            cameraPlaceholder.style.display = 'none';
            scanOverlay.style.display = 'block';
            startCameraBtn.style.display = 'none';
            captureBtn.style.display = 'flex';
            scanStatus.textContent = 'Camera active — Ready to scan';
            window.EcoCycle.showToast('Camera started successfully', 'success');
        } catch (error) {
            window.EcoCycle.showToast('Camera access denied', 'error');
        }
    });

    captureBtn.addEventListener('click', function() {
        captureAndAnalyze();
    });

    uploadBtn.addEventListener('click', function() {
        fileInput.click();
    });

    fileInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                video.style.display = 'none';
                const img = new Image();
                img.src = event.target.result;
                img.style.cssText = 'width:100%;height:100%;object-fit:cover;';
                document.querySelector('.camera-feed').appendChild(img);
                setTimeout(() => { simulateDetection(); }, 500);
            };
            reader.readAsDataURL(file);
        }
    });

    clearResultsBtn.addEventListener('click', function() {
        document.getElementById('resultsList').innerHTML = '';
        document.getElementById('emptyState').style.display = 'block';
        document.getElementById('resultsList').style.display = 'none';
        document.getElementById('summaryCard').style.display = 'none';
        document.getElementById('impactPreview').style.display = 'none';
        detectionBoxes.innerHTML = '';
        document.getElementById('detectionCount').textContent = '0';
        document.getElementById('processingSpeed').textContent = '0 ms';
        document.getElementById('confidence').textContent = '0';
    });

    function captureAndAnalyze() {
        scanStatus.textContent = 'Analysing image…';
        isScanning = true;
        const startTime = Date.now();
        setTimeout(() => {
            const processingTime = Date.now() - startTime;
            simulateDetection();
            document.getElementById('processingSpeed').textContent = processingTime + ' ms';
            scanStatus.textContent = 'Classification complete';
            isScanning = false;
        }, 1200);
    }

    function simulateDetection() {
        const detectedItems = [];
        const materialKeys = Object.keys(materials);
        const numItems = Math.floor(Math.random() * 3) + 2;
        for (let i = 0; i < numItems; i++) {
            const material = materialKeys[Math.floor(Math.random() * materialKeys.length)];
            detectedItems.push({
                type: material,
                ...materials[material],
                confidence: 85 + Math.random() * 10,
                quantity: Math.floor(Math.random() * 3) + 1
            });
        }
        displayResults(detectedItems);
        showDetectionBoxes(detectedItems);
        updateQuickStats(detectedItems);
    }

    function displayResults(items) {
        const resultsList = document.getElementById('resultsList');
        const emptyState = document.getElementById('emptyState');
        const summaryCard = document.getElementById('summaryCard');
        const impactPreview = document.getElementById('impactPreview');

        emptyState.style.display = 'none';
        resultsList.style.display = 'block';
        summaryCard.style.display = 'block';
        impactPreview.style.display = 'block';

        resultsList.innerHTML = '';
        let totalWeight = 0;
        let totalCO2 = 0;
        let recyclableCount = 0;
        let nonRecyclableCount = 0;

        // Bin colour map
        const binColors = {
            blue:   { label: '♻️ Recyclable — Blue Bin',    cls: 'blue' },
            red:    { label: '⚠️ Non-Recyclable — Red Bin', cls: 'red' },
            green:  { label: '🌿 Organic — Green Bin',      cls: 'blue' },
            purple: { label: '💻 E-Waste Bin',              cls: 'blue' }
        };

        items.forEach(item => {
            totalWeight += item.weight * item.quantity;
            totalCO2    += item.co2   * item.quantity;
            if (item.recyclable) recyclableCount++;
            else                  nonRecyclableCount++;

            const binInfo = binColors[item.bin] || binColors.red;

            const resultItem = document.createElement('div');
            resultItem.className = 'result-item scale-in';
            resultItem.innerHTML = `
                <div class="result-header">
                    <div class="result-type">${item.name}</div>
                    <span class="bin-indicator ${binInfo.cls}">${item.recyclable ? '♻️ Recyclable' : '⚠️ Non-Recyclable'}</span>
                </div>
                <div class="result-details">
                    <span>Qty: ${item.quantity}</span>
                    <span>•</span>
                    <span>${(item.weight * item.quantity).toFixed(2)} kg</span>
                </div>
                <div style="margin-top:6px;">
                    <span style="font-size:0.8125rem;color:var(--gray-500);">${binInfo.label}</span>
                </div>
            `;
            resultsList.appendChild(resultItem);
        });

        // Summary — no price column, only recyclable/non-recyclable counts
        // Remove the total-value display entirely
        const totalValueEl = document.getElementById('totalValue');
        if (totalValueEl) totalValueEl.closest('.summary-header') && (totalValueEl.textContent = '');

        document.getElementById('totalItems').textContent = items.length;
        document.getElementById('recyclableItems').textContent = recyclableCount;
        document.getElementById('nonRecyclableItems').textContent = nonRecyclableCount;
        document.getElementById('estimatedWeight').textContent = totalWeight.toFixed(2) + ' kg';

        // Environmental impact
        document.getElementById('co2Saved').textContent    = totalCO2.toFixed(2) + ' kg';
        document.getElementById('treesEquiv').textContent  = Math.floor(totalCO2 / 0.02);
        document.getElementById('waterSaved').textContent  = Math.floor(totalWeight * 50) + ' L';
    }

    function showDetectionBoxes(items) {
        detectionBoxes.innerHTML = '';
        items.forEach((item, index) => {
            const box = document.createElement('div');
            box.className = 'detection-box';
            box.style.cssText = `
                position:absolute;
                top:${20 + index * 22}%;
                left:${10 + (index % 2) * 40}%;
                width:30%;
                animation:fadeInBox 0.5s ease-out ${index * 0.3}s both;
            `;
            box.innerHTML = `
                <span class="detection-label">${item.name}</span>
                <span class="detection-value" style="color:${item.recyclable ? 'var(--success)' : 'var(--error)'}">
                    ${item.recyclable ? '♻️ Recyclable' : '⚠️ Not Recyclable'}
                </span>
            `;
            detectionBoxes.appendChild(box);
        });
    }

    function updateQuickStats(items) {
        document.getElementById('detectionCount').textContent = items.length;
        // Show confidence as plain number without extra % (the label already says %)
        const avgConf = items.reduce((sum, i) => sum + i.confidence, 0) / items.length;
        document.getElementById('confidence').textContent = avgConf.toFixed(0);
    }
});

function saveScanResults() {
    window.EcoCycle.showToast('Scan results saved successfully', 'success');
}
