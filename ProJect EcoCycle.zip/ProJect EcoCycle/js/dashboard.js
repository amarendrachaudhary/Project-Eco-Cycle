// ==========================================
// Dashboard Page JavaScript
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Chart.js if available
    if (typeof Chart !== 'undefined') {
        initializeCharts();
    }

    // Animate circular charts
    animateCircularCharts();

    // Animate progress bars
    animateProgressBars();

    // Load dashboard data
    loadDashboardData();
});

function initializeCharts() {
    const activityChart = document.getElementById('activityChart');
    
    if (activityChart) {
        new Chart(activityChart, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Items Recycled',
                    data: [12, 19, 15, 25, 22, 30, 28],
                    borderColor: 'rgb(16, 185, 129)',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
}

function animateCircularCharts() {
    const charts = document.querySelectorAll('.circular-chart');
    
    charts.forEach(chart => {
        const fill = chart.querySelector('.chart-fill');
        const text = chart.querySelector('.chart-text');
        const percentage = parseInt(text.textContent);
        
        const circumference = 2 * Math.PI * 40;
        const offset = circumference - (percentage / 100) * circumference;
        
        fill.style.strokeDasharray = `${circumference} ${circumference}`;
        fill.style.strokeDashoffset = circumference;
        
        setTimeout(() => {
            fill.style.transition = 'stroke-dashoffset 1s ease-out';
            fill.style.strokeDashoffset = offset;
        }, 100);
    });
}

function animateProgressBars() {
    const progressBars = document.querySelectorAll('.bar-fill');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const bar = entry.target;
                const width = bar.style.width;
                bar.style.width = '0%';
                
                setTimeout(() => {
                    bar.style.width = width;
                }, 100);
                
                observer.unobserve(bar);
            }
        });
    }, { threshold: 0.5 });
    
    progressBars.forEach(bar => observer.observe(bar));
}

function loadDashboardData() {
    // Simulate loading dashboard data
    // In production, this would fetch from an API
    
    const sampleData = {
        earnings: 2450,
        itemsRecycled: 342,
        co2Reduced: 1245,
        ecoPoints: 8540,
        recentScans: [
            {
                name: 'Mixed Recyclables',
                items: 3,
                types: 'Plastic, Glass, Paper',
                time: '2 hours ago',
                value: 45,
                icon: '📦'
            },
            {
                name: 'Plastic Bottles',
                items: 5,
                types: 'PET Plastic',
                time: 'Yesterday',
                value: 60,
                icon: '🥤'
            },
            {
                name: 'Newspapers',
                items: '2.5 kg',
                types: 'Paper',
                time: '2 days ago',
                value: 25,
                icon: '📰'
            }
        ]
    };

    // Update stats with animation
    animateValue('earnings', 0, sampleData.earnings, 1500, '₹');
    animateValue('items', 0, sampleData.itemsRecycled, 1500);
    animateValue('co2', 0, sampleData.co2Reduced, 1500, '', ' kg');
    animateValue('points', 0, sampleData.ecoPoints, 1500);
}

function animateValue(id, start, end, duration, prefix = '', suffix = '') {
    const element = document.getElementById(id);
    if (!element) return;
    
    const range = end - start;
    const increment = range / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
            element.textContent = prefix + end.toLocaleString() + suffix;
            clearInterval(timer);
        } else {
            element.textContent = prefix + Math.floor(current).toLocaleString() + suffix;
        }
    }, 16);
}

// Sidebar navigation
document.querySelectorAll('.sidebar .nav-item').forEach(item => {
    item.addEventListener('click', function(e) {
        if (this.getAttribute('href').startsWith('#')) {
            e.preventDefault();
            
            // Update active state
            document.querySelectorAll('.sidebar .nav-item').forEach(nav => {
                nav.classList.remove('active');
            });
            this.classList.add('active');
            
            // Scroll to section
            const target = this.getAttribute('href');
            document.querySelector(target)?.scrollIntoView({ behavior: 'smooth' });
        }
    });
});